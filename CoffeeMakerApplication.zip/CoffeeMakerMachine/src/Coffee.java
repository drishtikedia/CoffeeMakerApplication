import Test.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Coffee {
	static DrinkMachine dm = new DrinkMachine();
	static BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
	public static void startIO(){
        
        String input = "";
        
        //running loop
        while(true){  
        	System.out.println("\n -------------------------------- ");
            System.out.println("	Press M for Menu    \n -------------------------------- \n"
            		+ "  Press O to order and make coffee        \n -------------------------------- \n"
            		+ "  Press R to restock ingredients         \n -------------------------------- \n"
            		+ "  Press I to display Inventory        \n -------------------------------- \n"
            		+ "  Press B for billing details\n -------------------------------- \n"
            		+ "  Press C to clean machine	\n -------------------------------- \n"
            		+ "  Press Q to Quit and Exit           ");
            System.out.println(" -------------------------------- \n\n");
            try {
            	System.out.println("PLEASE ENTER YOUR CHOICE");
                input = reader.readLine().toLowerCase();
                switch(input) {
                case "":
                	continue;
                case "q":
                	 System.exit(0); 
                	 break;
                case "r":
                	System.out.println("Restocking  Ingredients.............\n");
                	 DrinkMachine.restockIngredients();
                	 DrinkMachine.updateMakeable();
                	 DrinkMachine.displayInventory();
                	 System.out.println("\n -------------------------------- ");
                 	System.out.println("\nINGREDIENTS RESTOCKED !");
                 	System.out.println("\n -------------------------------- ");
                	 break;
                case "m":
                	DrinkMachine.displayMenu();
                	break;
                case "b":
                	DrinkMachine.billingDetails();
                	break;
                case "o":
                	DrinkMachine.order();
                	System.out.println("\n -------------------------------- ");
                 	System.out.println("\nORDER COMPLETED !");
                 	System.out.println("\n -------------------------------- ");
                	break;
                case "i":
                	DrinkMachine.displayInventory();
                	break;
                case "c":
                	System.out.println("Cleaning Machine.............\n");
                	DrinkMachine.cleanMachine();
                	System.out.println("\n -------------------------------- ");
                	System.out.println("\nMACHINE  CLEANED !");
                	System.out.println("\n -------------------------------- ");
                	break;
                default:
                	throw new IOException();//legal, but invalid input
                }
            } catch (Exception e) {
                System.out.println("Invalid selection: " + input + "\n");//illegal input
            }
        }//running loop     
    }
	 public static void main(String[] args) throws IOException {
		 DrinkMachine.addAllIngredients();
         DrinkMachine.addAllDrinks();
         DrinkMachine.updateCosts();
         DrinkMachine.updateMakeable();
         System.out.println(" ----------------------------------------------------------------");
         System.out.println("|             Coffee Maker Application By Drishti		          |");
         System.out.println(" ----------------------------------------------------------------"); 
	        startIO();
	    }


}
