package Test;

public class BinFullDoCleanException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public BinFullDoCleanException(String s) {
		super(s);
	}

}
