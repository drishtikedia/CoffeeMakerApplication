package Test;

public class IngredientOutOfStockException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	IngredientOutOfStockException(String s){
		super(s);
	}

}
