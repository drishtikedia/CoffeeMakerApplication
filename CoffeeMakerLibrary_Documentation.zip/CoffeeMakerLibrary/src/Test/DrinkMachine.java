package Test;

import java.util.Collections;
import java.util.List;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Map;

public class DrinkMachine{
	static BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
    static List<Drink> drinkList = new ArrayList<Drink>();
    static List<Ingredient> ingredientList = new ArrayList<Ingredient>();
    //function to display all the menu items
    public static void displayMenu(){
    	System.out.println("\n -------------------------------- ");
     	System.out.println("\n			MENU				   !");
     	System.out.println("\n -------------------------------- ");
        int count = 1;
        System.out.println("Sn   \tName\t	Cost   \tAvaialblity");
        for (Drink d : drinkList){
            System.out.printf("%d\t%s\t$%.2f\t" + d.getMakeable() + "\n\n", count, d.getName(), d.getCost());
            count++;
        }
    }
    //function to display all the inventory items
    public static void displayInventory() {
    	System.out.println("\n -------------------------------- ");
     	System.out.println("\n			INVENTORY			   !");
     	System.out.println("\n -------------------------------- ");
    	//lambda expression
     	System.out.println("Ingredient\tStock\t");
        ingredientList.forEach((Ingredient i)->{
            System.out.println(i.getName() + "\t\t" + i.getStock() + "\n");
        });
    }

    public static void updateMakeable(){
//        LAMBDA EXPRESSION USED
    	drinkList.forEach((Drink d)->{
            Map<String, Integer> currRecipe = d.getRecipe();
            for (Ingredient i : ingredientList){
                if (currRecipe.containsKey(i.getName()) && i.getStock() < currRecipe.get(i.getName())){
                    d.setMakeable(false);
                    break;//check next drink
                }
                d.setMakeable(true);
            }//Ingredient loop
        });//Drink loop
    }
    static double total_cost;
    public static void updateCosts(){
    	//lambda expression used
       drinkList.forEach((Drink d)->{;
            double currCost = 0;
            Map<String, Integer> currRecipe = d.getRecipe();
            for (Ingredient i : ingredientList){
                if (currRecipe.containsKey(i.getName())){
                    currCost += i.getCost()*currRecipe.get(i.getName());
                }
            }
            d.setCost(currCost);
            
        });//outer
    }
    public static void order() throws NumberFormatException, IOException, IngredientOutOfStockException, BinFullDoCleanException {
		DrinkMachine.displayMenu();
		System.out.println("please enter item number of  your choice from the menu");
		String input=reader.readLine();
		DrinkMachine.makeDrink(DrinkMachine.drinkList.get(Integer.parseInt(input)-1));
	}
    public static void billingDetails() {
//    	System.out.println("Billing Details");
//    	drinkList.forEach((Drink d)->{
//    		if(d.getCount()>0) {
//    			System.out.println(d.getName()+"\t"+"\t"+d.getCost()+"");
//    			total_cost=total_cost+d.getCost()*d.getCount();
//    		}
//    	});
    	 System.out.println("Total amount to be paid: "+total_cost);
    }
    public static void makeDrink(Drink drink) throws IngredientOutOfStockException,BinFullDoCleanException{
    	//custom exception for ingredients out of stock
    	try {
    		if(drink.getMakeable()){
            System.out.println("Dispensing: " + drink.getName() + "\n");
            int ctr=0;
            total_cost=total_cost+drink.getCost();//i
            //lambda expression used
           ingredientList.forEach((Ingredient i)->{
                if(drink.getRecipe().containsKey(i.getName())){
                    i.setStock(i.getStock()-drink.getRecipe().get(i.getName()));
                    drink.setCount(ctr);
                }
            });
        }else{
            //System.out.println("Out of stock: " + drink.getName() + "\n");
        	
        	throw new IngredientOutOfStockException("Ingredient out of stock");
        }}
    	catch(Exception m) {
    		 System.out.println(" Ingredient Out of stock: " + drink.getName() + "\n");
    	}
    	try {
    		if(isBinFull())
    			throw new BinFullDoCleanException("BinFullDoClean");
    	}
    	catch(Exception e) {
    		System.out.println("Bin is full , press R to restock the ingredients and clean the bin");
    	}
        
        updateMakeable();
        updateCosts();
       
    }
    
    //restocking ingredients
    public static void restockIngredients(){
        ingredientList.forEach((Ingredient i)->{
            i.setStock(10);
        });
        //updating makeable
        updateMakeable();
        //displaying all the inventory items
        displayInventory();
    }
    //function to check if the bin is full i.e all the stock is over
    static boolean bool;
    public static boolean isBinFull() {
    	bool= true;
    	ingredientList.forEach((Ingredient i)->{
           if(i.getStock()>0)
        	   bool=false;
        });
    	return bool;
    }
    //function to clean the machine i.e set all the stock to 0
    public static void cleanMachine() {
    	ingredientList.forEach((Ingredient i)->{
            i.setStock(0);
        });
    	//updating makeable
        updateMakeable();
        //displaying all the inventory items
        displayInventory();
    }

    //Add ingredients through addAllIngredients
    public static void addIngredient(Ingredient ingredient){
        ingredientList.add(ingredient);
    }
    //Add drinks through addAllDrinks
    public static void addDrink(String name, String[] recipe){
        drinkList.add(new Drink(name, recipe));
    }
    //function to add all the ingredients to the collection
    public static void addAllIngredients(){
        addIngredient(new Ingredient("Coffee", 0.75));
        addIngredient(new Ingredient("Decaf Coffee", 0.75));
        addIngredient(new Ingredient("Sugar", 0.25));
        addIngredient(new Ingredient("Cream", 0.25));
        addIngredient(new Ingredient("Steamed Milk", 0.35));
        addIngredient(new Ingredient("Foamed Milk", 0.35));
        addIngredient(new Ingredient("Espresso", 1.10));
        addIngredient(new Ingredient("Cocoa", 0.90));
        addIngredient(new Ingredient("Whipped Cream", 1.00));   

        Collections.sort(ingredientList);
    }
    //function to add all the drinks to the collection
    public static void addAllDrinks(){  
        addDrink("Coffee", new String[]{"Coffee", "Coffee", "Coffee", "Sugar", "Cream"});
        addDrink("Decaf Coffee", new String[]{"Decaf Coffee", "Decaf Coffee", "Decaf Coffee", "Sugar", "Cream"});
        addDrink("Caffe Latte", new String[]{"Espresso", "Espresso", "Steamed Milk"});
        addDrink("Caffe Americano", new String[]{"Espresso", "Espresso", "Espresso"});
        addDrink("Caffe Mocha", new String[]{"Espresso", "Cocoa", "Steamed Milk", "Whipped Cream"});
        addDrink("Cappuccino", new String[]{"Espresso", "Espresso", "Steamed Milk", "Foamed Milk"});

        Collections.sort(drinkList);
    }

}