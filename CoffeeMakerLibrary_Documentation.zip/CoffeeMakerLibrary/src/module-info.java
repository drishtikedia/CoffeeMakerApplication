module CoffeeMakerLibrary {
}